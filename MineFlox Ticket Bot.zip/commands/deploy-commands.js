import { REST, Routes, SlashCommandBuilder } from 'discord.js';
import { config } from '../config.js';
import dotenv from 'dotenv';

dotenv.config();

const commands = [
  new SlashCommandBuilder()
    .setName('close')
    .setDescription('Destek talebini kapatır'),
  new SlashCommandBuilder()
    .setName('closereason')
    .setDescription('Destek talebini belirtilen sebeple kapatır')
    .addStringOption(option =>
      option
        .setName('reason')
        .setDescription('Kapatma sebebi')
        .setRequired(true)
    ),
];

const rest = new REST().setToken(process.env.TOKEN);

try {
  console.log('Slash komutları yükleniyor...');

  await rest.put(
    Routes.applicationCommands(process.env.CLIENT_ID),
    { body: commands },
  );

  console.log('Slash komutları başarıyla yüklendi!');
} catch (error) {
  console.error('Komutlar yüklenirken hata oluştu:', error);
}