import { createTicketChannel } from '../utils/ticketUtils.js';
import { closeTicket } from '../utils/ticketUtils.js';

export async function handleModal(interaction) {
  if (interaction.customId === 'ticket_modal') {
    const reason = interaction.fields.getTextInputValue('ticket_reason');
    await createTicketChannel(interaction, reason);
  }

  if (interaction.customId === 'close_ticket_modal') {
    const reason = interaction.fields.getTextInputValue('close_reason');
    await closeTicket(interaction, reason);
  }
}