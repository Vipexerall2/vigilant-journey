import { 
  ActionRowBuilder, 
  ButtonBuilder, 
  ButtonStyle,
  EmbedBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle
} from 'discord.js';
import { closeTicket } from '../utils/ticketUtils.js';
import { createTicketModal } from '../utils/modalUtils.js';
import { v3 } from '../utils/v1.js';

export async function handleButton(interaction) {
  if (interaction.customId === 'create_ticket') {
    await createTicketModal(interaction);
  }

  if (interaction.customId === 'support_rules') {
    const msg = await v3();
    const rulesEmbed = new EmbedBuilder()
      .setTitle('📜 Destek Kuralları')
      .setColor('#2f3136')
      .setDescription(`**Destek Talebi Kuralları:**\n
1. Her hesap için aynı anda sadece bir destek talebi açabilirsiniz.
2. Gereksiz destek talebi açmak yasaktır.
3. Destek talebinde saygılı olun ve sabırla bekleyin.
4. Destek ekibine karşı saygılı olun.
5. Spam yapmayın ve gereksiz etiketlemelerden kaçının.
6. Sorunuzu açık ve anlaşılır bir şekilde belirtin.
7. Destek talebiniz çözüldüğünde kapatmayı unutmayın.\n\n${msg}`);

    await interaction.reply({ embeds: [rulesEmbed], ephemeral: true });
  }

  if (interaction.customId === 'close_ticket') {
    const msg = await v3();
    const confirmEmbed = new EmbedBuilder()
      .setTitle('Destek Talebini Kapatma Onayı')
      .setDescription(`Bu destek talebini kapatmak istediğinize emin misiniz?\n\n${msg}`)
      .setColor('#ff0000');

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('confirm_close')
          .setLabel('Evet')
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId('cancel_close')
          .setLabel('Hayır')
          .setStyle(ButtonStyle.Secondary)
      );

    await interaction.reply({ embeds: [confirmEmbed], components: [row] });
  }

  if (interaction.customId === 'close_ticket_reason') {
    const modal = new ModalBuilder()
      .setCustomId('close_ticket_modal')
      .setTitle('Destek Talebini Kapat');

    const reasonInput = new TextInputBuilder()
      .setCustomId('close_reason')
      .setLabel('Kapatma Sebebi')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true);

    modal.addComponents(new ActionRowBuilder().addComponents(reasonInput));
    await interaction.showModal(modal);
  }

  if (interaction.customId === 'confirm_close') {
    await closeTicket(interaction, 'Destek talebi kapatıldı');
  }

  if (interaction.customId === 'cancel_close') {
    const msg = await v3();
    await interaction.update({ 
      content: `Destek talebi kapatma işlemi iptal edildi.\n\n${msg}`, 
      embeds: [], 
      components: [] 
    });
  }

  if (interaction.customId === 'delete_ticket') {
    await interaction.channel.delete();
  }
}