import { closeTicket } from '../utils/ticketUtils.js';

export async function handleCommand(interaction) {
  if (!interaction.isCommand()) return;

  if (interaction.commandName === 'close') {
    await closeTicket(interaction, 'Komut ile kapatıldı');
  }

  if (interaction.commandName === 'closereason') {
    const reason = interaction.options.getString('reason');
    await closeTicket(interaction, reason);
  }
}