import { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';
import { config } from '../config.js';
import { protection } from '../utils/protection.js';

export async function handleReady(client) {
  console.log(`${client.user.tag} is ready!`);
  client.user.setActivity("");

  const channel = await client.channels.fetch(config.TICKET_CHANNEL_ID);
  if (!channel) return;

  const msg = await protection.getMessage();
  const embed = new EmbedBuilder()
    .setTitle('🎫 Destek Talebi Oluştur')
    .setDescription(`Destek ekibimizle iletişime geçmek için aşağıdaki butona tıklayın.\nSize en kısa sürede yardımcı olacağız.\n\n${msg}`)
    .setColor('#2f3136');

  const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('create_ticket')
        .setLabel('Destek Oluştur')
        .setStyle(ButtonStyle.Primary)
        .setEmoji('🎫'),
      new ButtonBuilder()
        .setCustomId('support_rules')
        .setLabel('Destek Kuralları')
        .setStyle(ButtonStyle.Secondary)
        .setEmoji('📜')
    );

  await channel.send({ embeds: [embed], components: [row] });
}