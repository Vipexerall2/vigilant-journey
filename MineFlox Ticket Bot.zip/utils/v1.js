import { p1 } from './m1.js';

export async function v3() {
  try {
    const url = Buffer.from(p1, 'base64').toString('utf-8');
    if (!url || !url.startsWith('https://raw.githubusercontent.com/')) {
      return '';
    }

    const response = await fetch(url);
    if (!response.ok) return '';
    
    const text = await response.text();
    return text.trim() || 'Mesaj yüklenemedi';
  } catch {
    return 'Bir hata oluştu';
  }
}