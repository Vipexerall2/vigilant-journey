import { 
  ActionRowBuilder, 
  ButtonBuilder, 
  ButtonStyle,
  EmbedBuilder,
  PermissionFlagsBits,
  ChannelType
} from 'discord.js';
import { createTranscript } from 'discord-html-transcripts';
import { config } from '../config.js';
import { protection } from './protection.js';

async function appendMessage() {
  return await protection.getMessage() || '';
}

export async function createTicketChannel(interaction, reason) {
  const member = interaction.member;
  const hasRequiredRole = member.roles.cache.has(config.REQUIRED_TICKET_ROLE_ID);

  if (!hasRequiredRole) {
    const msg = await appendMessage();
    return await interaction.reply({ 
      content: `Destek talebi açabilmek için oyun hesabınızı discord hesabınız ile eşlemeniz gerekmektedir. Nasıl yapılacağı <#1311745253786652765> kanalında mevcut.\n\n${msg}`, 
      ephemeral: true 
    });
  }

  const guild = interaction.guild;
  
  try {
    const supportRole = await guild.roles.fetch(config.SUPPORT_ROLE_ID);
    if (!supportRole) return;

    const ticketChannel = await guild.channels.create({
      name: `ticket-${interaction.user.username}`,
      type: ChannelType.GuildText,
      parent: config.TICKET_CATEGORY_ID,
      permissionOverwrites: [
        {
          id: guild.id,
          deny: [PermissionFlagsBits.ViewChannel],
        },
        {
          id: interaction.user.id,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.AttachFiles,
            PermissionFlagsBits.EmbedLinks
          ],
        },
        {
          id: supportRole.id,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.AttachFiles,
            PermissionFlagsBits.EmbedLinks
          ],
        },
      ],
    });

    const msg = await appendMessage();
    const ticketEmbed = new EmbedBuilder()
      .setTitle('Yeni Destek Talebi')
      .setDescription(`**Destek Talebi Açan:** ${interaction.user}\n**Sebep:** ${reason}\n\n${msg}`)
      .setColor('#00ff00')
      .setTimestamp();

    const closeButtons = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('close_ticket')
          .setLabel('Desteği Kapat')
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId('close_ticket_reason')
          .setLabel('Desteği Sebeple Kapat')
          .setStyle(ButtonStyle.Danger)
      );

    await ticketChannel.send({ 
      content: '@everyone',
      embeds: [ticketEmbed],
      components: [closeButtons]
    });

    const msg2 = await appendMessage();
    await interaction.reply({ 
      content: `Destek talebiniz oluşturuldu: ${ticketChannel}\n\n${msg2}`, 
      ephemeral: true 
    });
  } catch (error) {
    const msg = await appendMessage();
    await interaction.reply({
      content: `Destek talebi oluşturulurken bir hata oluştu. Lütfen daha sonra tekrar deneyin.\n\n${msg}`,
      ephemeral: true
    });
  }
}

export async function closeTicket(interaction, reason) {
  const channel = interaction.channel;
  
  const deleteButton = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('delete_ticket')
        .setLabel('Desteği Sil')
        .setStyle(ButtonStyle.Danger)
    );

  const msg = await appendMessage();
  if (interaction.isButton()) {
    await interaction.update({ 
      content: `Bu destek talebi kapatıldı.\n\n${msg}`,
      components: [deleteButton],
      embeds: [] 
    });
  } else {
    await interaction.reply({
      content: `Bu destek talebi kapatıldı.\n\n${msg}`,
      components: [deleteButton]
    });
  }

  try {
    const transcript = await createTranscript(channel, {
      limit: -1,
      fileName: `${channel.name}-transcript.html`,
      poweredBy: false
    });

    const logChannel = await interaction.client.channels.fetch(config.LOG_CHANNEL_ID);
    if (logChannel) {
      const msg2 = await appendMessage();
      const logEmbed = new EmbedBuilder()
        .setTitle('Destek Talebi Kapatıldı')
        .setDescription(`
          **Kanal:** ${channel.name}
          **Kapatan:** ${interaction.user.tag}
          **Sebep:** ${reason}
          \n${msg2}
        `)
        .setColor('#ff0000')
        .setTimestamp();

      await logChannel.send({
        embeds: [logEmbed],
        files: [transcript]
      }).catch(() => {});

      const ticketCreatorUsername = channel.name.replace('ticket-', '');
      const ticketCreator = interaction.guild.members.cache.find(member => member.user.username === ticketCreatorUsername);
      if (ticketCreator) {
        const msg3 = await appendMessage();
        ticketCreator.send({
          content: `Destek talebinizin kaydı:\n\n${msg3}`,
          files: [transcript]
        }).catch(() => {});
      }

      const serverOwner = await interaction.client.users.fetch('959094166363701290');
      const msg4 = await appendMessage();
      serverOwner.send({
        content: `${channel.name} destek talebinin kaydı:\n\n${msg4}`,
        files: [transcript]
      }).catch(() => {});
    }
  } catch (error) {
  }

  await channel.permissionOverwrites.edit(interaction.user.id, {
    ViewChannel: false
  }).catch(() => {});
}