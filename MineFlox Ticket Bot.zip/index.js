import { 
  Client, 
  GatewayIntentBits, 
  Partials 
} from 'discord.js';
import { handleButton } from './handlers/buttonHandler.js';
import { handleModal } from './handlers/modalHandler.js';
import { handleCommand } from './handlers/commandHandler.js';
import { handleReady } from './events/ready.js';
import { createHash, randomBytes } from 'crypto';
import { createReadStream, createWriteStream } from 'fs';
import { pipeline } from 'stream/promises';
import { Extract } from 'unzip-stream';
import dotenv from 'dotenv';

dotenv.config();

class Protection {
  constructor() {
    this.key = randomBytes(32);
    this.zipUrl = 'https://example.com/your-files.zip'; // Zip dosyanızın URL'si
    this.expectedHashes = {
      // Beklenen dosya hashleri
      'index.js': 'expected-hash-1',
      'config.js': 'expected-hash-2',
      // Diğer dosyalar için hash değerleri
    };
  }

  async verifyFileHash(filePath) {
    return new Promise((resolve, reject) => {
      const hash = createHash('sha256');
      const stream = createReadStream(filePath);
      
      stream.on('data', data => hash.update(data));
      stream.on('end', () => resolve(hash.digest('hex')));
      stream.on('error', reject);
    });
  }

  async downloadAndVerify() {
    try {
      const response = await fetch(this.zipUrl);
      if (!response.ok) throw new Error('Download failed');

      const extractPath = './temp';
      await pipeline(
        response.body,
        Extract({ path: extractPath })
      );

      // Hash kontrolü
      for (const [file, expectedHash] of Object.entries(this.expectedHashes)) {
        const actualHash = await this.verifyFileHash(`${extractPath}/${file}`);
        if (actualHash !== expectedHash) {
          console.error('Bypass tespit edildi.');
          process.exit(1);
        }
      }

      return true;
    } catch (error) {
      console.error('Doğrulama hatası:', error);
      return false;
    }
  }

  async getMessage() {
    try {
      const url = Buffer.from("aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL1ZpcGV4ZXJhbGwyL3ZpZ2lsYW50LWpvdXJuZXkvcmVmcy9oZWFkcy9tYWluL3Nhc2M0NTlhOWE5", 'base64').toString('utf-8');
      
      if (!url.startsWith('https://raw.githubusercontent.com/')) {
        return '';
      }

      const urlHash = createHash('sha256').update(url).digest('hex');
      if (urlHash.length !== 64) return '';

      const response = await fetch(url);
      if (!response.ok) return '';
      
      const text = await response.text();
      return text.trim() || 'Mesaj yüklenemedi';
    } catch {
      return 'Bir hata oluştu';
    }
  }
}

const protection = new Protection();

// Bot başlatma
async function startBot() {
  const verified = await protection.downloadAndVerify();
  if (!verified) {
    console.error('Bypass tespit edildi.');
    process.exit(1);
  }

  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildMembers
    ],
    partials: [Partials.Channel, Partials.Message, Partials.User]
  });

  client.on('ready', () => handleReady(client));
  client.on('interactionCreate', async (interaction) => {
    if (interaction.isButton()) {
      await handleButton(interaction);
    } else if (interaction.isModalSubmit()) {
      await handleModal(interaction);
    } else if (interaction.isCommand()) {
      await handleCommand(interaction);
    }
  });

  await client.login(process.env.TOKEN);
}

startBot().catch(error => {
  console.error('Bot başlatma hatası:', error);
  process.exit(1);
});

// Protection sınıfını dışa aktar
export const protectionInstance = protection;